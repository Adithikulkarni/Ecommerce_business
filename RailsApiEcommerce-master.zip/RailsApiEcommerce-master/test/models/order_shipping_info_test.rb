require 'test_helper'

class OrderShippingInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
