require 'test_helper'

class FileUploadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
