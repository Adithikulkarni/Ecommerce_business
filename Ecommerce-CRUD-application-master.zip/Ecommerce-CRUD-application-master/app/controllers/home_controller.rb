class HomeController < ApplicationController
  def index
  end

  def about
  end
  
end
