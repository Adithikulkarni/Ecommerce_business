class Address < ApplicationRecord
end
